# Cada conta possui um cliente, saldo, limite, sacar, depositar e consultar saldo

class Conta:  # Nome da Classe geralmente começa com maiúscula

    def __init__(self, cliente, saldo, limite):  # Contrói o objeto
        self.cliente = cliente
        self.saldo = saldo
        self.limite = 0 - limite

    def depositar(self, quant):
        if quant > 0:
            self.saldo += quant
            print("Foi depositado:", quant)
        else:
            print("Erro no depósito")

    def consulta_saldo(self):
        return self.saldo

    def sacar(self, quant):
        if self.saldo - quant < self.limite:
            print("Saldo Insuficiente")
        else:
            self.saldo -= quant
            print("Foi sacado:", quant)