"""
EXERCÍCIO

Crie um software de gerenciamento bancário!
Esse software poderá ser capaz de criar clientes e contas
Cada cliente possui nome, cpf, idade
Cada conta possui um cliente, saldo, limite, sacar, depositar e consultar saldo

"""
from cliente import Cliente  # De dentro do arquivo cliente importa a classe Cliente. Faz com que o conteúdo da classe venha para main
from conta import Conta
from time import sleep

def menu():
    print("===================================")
    print("**** [ GERENTE BANCARIO v.1.0 ] ***")
    print("===================================")
    print("[ 1 ] Cadastrar Cliente")
    print("[ 2 ] Sair")
    print("")
    pergunta = int(input("Selecione a Opção.:"))
    if pergunta == 1:
        cad_cliente()
    else:
        exit(0)

def cad_cliente():
    nome1 = input("Digite o Nome do Cliente...:")
    idade1 = int(input("Digite a Idade do Cliente..:"))
    cpf1 = float(input("Digite o CPF do Cliente....:"))
    saldo_cli1 = float(input("Saldo do Cliente...........:"))
    limite_cli1 = float(input("Limite do Cliente..........:"))

    cliente1 = Cliente(nome1, cpf1, idade1)

    print("=======================")
    print("DADOS DA CONTA")
    print("=======================")
    print(cliente1.nome)
    print("CPF:", cliente1.cpf)
    print(cliente1.idade, "anos")
    print("====================================")
    print("CLIENTE CADASTRADO COM SUCESSO!")

    conta_do_cliente1 = Conta(cliente1, saldo_cli1, limite_cli1)
    sleep(3)


    pergunta1 = str(input("Deseja efetuar depósito? <s/n> "))
    if pergunta1 in ['s', 'S', 'sim', 'Sim', 'SIM', 'sIM']:
        depositando = float(input("Deseja depositar quanto? "))
        conta_do_cliente1.depositar(depositando)
        print("Saldo: ", conta_do_cliente1.consulta_saldo())
        sleep(5)

    pergunta2 = str(input("Deseja efetuar saque? <s/n> "))
    if pergunta2 in ['s', 'S', 'sim', 'Sim', 'SIM', 'sIM']:
        sacando = float(input("Deseja sacar quanto? "))
        conta_do_cliente1.sacar(sacando)
        print("Saldo: ", conta_do_cliente1.consulta_saldo())
        sleep(5)

while True:
    menu()



